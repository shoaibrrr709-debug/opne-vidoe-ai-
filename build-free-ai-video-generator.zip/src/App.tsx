import { AnimatePresence, motion } from "framer-motion";
import { useMemo, useState, type ReactNode } from "react";

type FormState = {
  idea: string;
  style: string;
  length: string;
  ratio: string;
  audience: string;
  tone: string;
};

type GeneratedPlan = {
  prompt: string;
  beats: string[];
  exportNote: string;
  toolPath: { name: string; detail: string }[];
};

const styleOptions = [
  "Cinematic",
  "Product demo",
  "Explainer",
  "Short reel",
  "App promo",
];

const lengthOptions = ["10s", "15s", "30s", "60s"];
const ratioOptions = ["9:16", "16:9", "1:1"];
const audienceOptions = ["Creators", "Founders", "Students", "Brands"];
const toneOptions = ["Bold", "Clean", "Friendly", "Premium"];

const toolRows = [
  {
    phase: "Script",
    description: "Shape the idea into a tight hook, body, and CTA before you generate anything.",
    examples: "ChatGPT, Gemini, Claude",
  },
  {
    phase: "Generate",
    description: "Turn a prompt into motion tests, b-roll, or a full first cut.",
    examples: "Runway, Pika, Luma, open-source video models",
  },
  {
    phase: "Polish",
    description: "Add captions, cuts, color, and platform-friendly ratios.",
    examples: "CapCut, DaVinci Resolve, Canva",
  },
];

const defaultForm: FormState = {
  idea: "A free AI tool for creating 15-second product launch videos.",
  style: "Cinematic",
  length: "15s",
  ratio: "9:16",
  audience: "Creators",
  tone: "Bold",
};

function buildPlan(form: FormState): GeneratedPlan {
  const hook = `Create a ${form.length} ${form.style.toLowerCase()} AI video for ${form.audience.toLowerCase()} in ${form.ratio} format with a ${form.tone.toLowerCase()} tone.`;

  return {
    prompt: [
      hook,
      `Idea: ${form.idea.trim()}`,
      "Use a strong first 2 seconds, clear motion, and one obvious call to action.",
      "Keep the scene lighting polished, text readable, and transitions clean.",
    ].join(" "),
    beats: [
      "Open with the main problem or promise in a single visual beat.",
      "Show the workflow or product payoff with one focused motion sequence.",
      "End with a direct CTA and a simple on-screen title.",
    ],
    exportNote: `Export as ${form.ratio} with burned-in captions and a ${form.tone.toLowerCase()} finish for ${form.length}.`,
    toolPath: [
      {
        name: "Prompt builder",
        detail: "Refine the idea into a shot list and a text-to-video prompt.",
      },
      {
        name: "Video generator",
        detail: "Use a free-tier or open-source generator to test the opening scene.",
      },
      {
        name: "Editor",
        detail: "Trim, caption, and resize the final export for social platforms.",
      },
    ],
  };
}

function FieldLabel({ children }: { children: ReactNode }) {
  return <label className="text-sm font-medium text-slate-300">{children}</label>;
}

export default function App() {
  const [form, setForm] = useState<FormState>(defaultForm);
  const [result, setResult] = useState<GeneratedPlan>(() => buildPlan(defaultForm));
  const [copied, setCopied] = useState(false);

  const inputPreview = useMemo(
    () => `${form.style} / ${form.length} / ${form.ratio} / ${form.audience}`,
    [form]
  );

  const handleChange = (key: keyof FormState, value: string) => {
    setForm((current) => ({ ...current, [key]: value }));
  };

  const handleGenerate = () => {
    setResult(buildPlan(form));
    setCopied(false);
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(result.prompt);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#050816] text-slate-50 antialiased">
      <main>
        <section className="relative isolate overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,_rgba(99,102,241,0.28),_transparent_38%),radial-gradient(circle_at_85%_12%,_rgba(56,189,248,0.18),_transparent_32%),linear-gradient(180deg,_#09101f_0%,_#050816_55%,_#050816_100%)]" />
          <motion.div
            aria-hidden="true"
            className="absolute left-[-8rem] top-20 h-72 w-72 rounded-full bg-cyan-400/20 blur-3xl"
            animate={{ x: [0, 22, 0], y: [0, -16, 0] }}
            transition={{ duration: 14, repeat: Infinity, ease: "easeInOut" }}
          />
          <motion.div
            aria-hidden="true"
            className="absolute right-[-6rem] top-32 h-80 w-80 rounded-full bg-indigo-500/20 blur-3xl"
            animate={{ x: [0, -18, 0], y: [0, 18, 0] }}
            transition={{ duration: 16, repeat: Infinity, ease: "easeInOut" }}
          />

          <div className="mx-auto grid min-h-screen w-full max-w-7xl grid-cols-1 items-center gap-10 px-6 py-8 lg:grid-cols-[0.95fr_1.05fr] lg:px-8">
            <div className="relative z-10 max-w-xl">
              <div className="mb-6 inline-flex items-center gap-3 text-sm font-medium tracking-[0.2em] text-cyan-200/85 uppercase">
                <span className="h-2.5 w-2.5 rounded-full bg-cyan-300 shadow-[0_0_24px_rgba(103,232,249,0.85)]" />
                Open Video
              </div>
              <h1 className="max-w-xl text-5xl font-semibold tracking-tight text-white sm:text-6xl lg:text-7xl">
                Free AI video tools, turned into a simple workflow.
              </h1>
              <p className="mt-6 max-w-lg text-base leading-7 text-slate-300 sm:text-lg">
                Build prompts, compare free-capable tools, and generate a cleaner first cut for reels,
                explainers, and product launches.
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-3">
                <a
                  href="#generator"
                  className="inline-flex items-center justify-center rounded-full bg-white px-5 py-3 text-sm font-semibold text-slate-950 transition hover:bg-cyan-100"
                >
                  Build a video prompt
                </a>
                <a
                  href="#tools"
                  className="inline-flex items-center justify-center rounded-full border border-white/15 bg-white/5 px-5 py-3 text-sm font-semibold text-white transition hover:border-cyan-300/40 hover:bg-white/10"
                >
                  See free tool stack
                </a>
              </div>
            </div>

            <div className="relative z-10">
              <motion.div
                className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-white/5 shadow-2xl shadow-black/40 backdrop-blur-2xl"
                initial={{ opacity: 0, y: 24 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, ease: "easeOut" }}
              >
                <div className="flex items-center justify-between border-b border-white/10 px-5 py-4 text-xs uppercase tracking-[0.25em] text-slate-300/80">
                  <span>Prompt canvas</span>
                  <span>{inputPreview}</span>
                </div>
                <div className="grid gap-0 lg:grid-cols-[1.15fr_0.85fr]">
                  <div className="relative min-h-[24rem] overflow-hidden p-5 sm:min-h-[29rem] lg:p-6">
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_35%,_rgba(56,189,248,0.18),_transparent_40%),linear-gradient(135deg,_rgba(15,23,42,0.98),_rgba(8,15,28,0.9))]" />
                    <div className="relative h-full rounded-[1.6rem] border border-white/10 bg-[#08111f]/90 p-4">
                      <div className="flex items-center justify-between text-[0.7rem] uppercase tracking-[0.26em] text-slate-400">
                        <span>Preview</span>
                        <span>Live motion</span>
                      </div>
                      <div className="mt-4 grid h-[11rem] place-items-center overflow-hidden rounded-[1.2rem] border border-white/10 bg-[linear-gradient(135deg,_rgba(14,23,41,0.9),_rgba(20,33,58,0.88))] sm:h-[13rem]">
                        <div className="absolute inset-x-8 top-8 h-16 rounded-full bg-cyan-400/20 blur-2xl" />
                        <motion.div
                          className="absolute left-8 right-8 top-12 h-[2px] bg-gradient-to-r from-transparent via-cyan-200 to-transparent opacity-80"
                          animate={{ y: [0, 116, 0] }}
                          transition={{ duration: 4.5, repeat: Infinity, ease: "easeInOut" }}
                        />
                        <div className="relative flex h-24 w-24 items-center justify-center rounded-full border border-white/15 bg-white/10 text-white shadow-[0_0_40px_rgba(103,232,249,0.2)]">
                          <div className="ml-1 h-0 w-0 border-y-[12px] border-l-[20px] border-y-transparent border-l-white" />
                        </div>
                      </div>

                      <div className="mt-4 space-y-3">
                        <div className="flex items-center gap-3 text-xs text-slate-300">
                          <span className="h-2 w-2 rounded-full bg-cyan-300" />
                          Scene flow
                        </div>
                        <div className="space-y-2 rounded-[1rem] border border-white/10 bg-white/5 p-3">
                          {[
                            "Hook: reveal the problem in one shot",
                            "Motion: show the workflow and the payoff",
                            "CTA: end with one line and a clear action",
                          ].map((line, index) => (
                            <motion.div
                              key={line}
                              className="h-2 rounded-full bg-white/10"
                              initial={{ scaleX: 0.7, opacity: 0.45 }}
                              animate={{ scaleX: [0.7, 1, 0.7], opacity: [0.45, 1, 0.45] }}
                              transition={{ duration: 5 + index, repeat: Infinity, ease: "easeInOut" }}
                              style={{ transformOrigin: "left" }}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="border-t border-white/10 lg:border-l lg:border-t-0">
                    <div className="space-y-5 p-5 sm:p-6">
                      <div>
                        <p className="text-xs uppercase tracking-[0.24em] text-cyan-200/80">Prompt</p>
                        <p className="mt-3 text-lg leading-7 text-slate-100">
                          {result.prompt.slice(0, 180)}...
                        </p>
                      </div>
                      <div className="rounded-[1.3rem] border border-white/10 bg-white/5 p-4">
                        <p className="text-xs uppercase tracking-[0.24em] text-slate-400">Output notes</p>
                        <p className="mt-3 text-sm leading-6 text-slate-300">{result.exportNote}</p>
                      </div>
                      <div className="rounded-[1.3rem] border border-white/10 bg-white/5 p-4">
                        <p className="text-xs uppercase tracking-[0.24em] text-slate-400">Tool path</p>
                        <div className="mt-3 space-y-3">
                          {result.toolPath.map((step, index) => (
                            <div key={step.name} className="flex gap-3">
                              <div className="mt-1 h-2.5 w-2.5 rounded-full bg-cyan-300" />
                              <div>
                                <p className="text-sm font-semibold text-white">
                                  {index + 1}. {step.name}
                                </p>
                                <p className="text-sm leading-6 text-slate-300">{step.detail}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        <section className="border-y border-white/10 bg-[#07101d]">
          <div className="mx-auto grid max-w-7xl gap-0 px-6 py-14 lg:grid-cols-3 lg:px-8">
            <div className="pb-6 lg:pb-0 lg:pr-8">
              <p className="text-xs uppercase tracking-[0.28em] text-cyan-200/80">How it works</p>
              <h2 className="mt-3 text-3xl font-semibold tracking-tight text-white">One workflow, not a dashboard.</h2>
            </div>
            <div className="space-y-6 border-t border-white/10 pt-6 lg:col-span-2 lg:grid lg:grid-cols-3 lg:space-y-0 lg:divide-x lg:divide-white/10 lg:border-t-0 lg:pt-0">
              {[
                ["1. Write", "Start with a plain-language idea and a target audience."],
                ["2. Generate", "Turn the brief into prompts and motion directions."],
                ["3. Publish", "Export the right ratio with captions and a clear CTA."],
              ].map(([title, copy]) => (
                <div key={title} className="lg:px-6">
                  <h3 className="text-lg font-semibold text-white">{title}</h3>
                  <p className="mt-3 text-sm leading-6 text-slate-300">{copy}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="generator" className="bg-[#050816] px-6 py-16 lg:px-8">
          <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[0.9fr_1.1fr]">
            <motion.div
              className="rounded-[1.75rem] border border-white/10 bg-white/5 p-6 backdrop-blur"
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.35 }}
              transition={{ duration: 0.6 }}
            >
              <p className="text-xs uppercase tracking-[0.26em] text-cyan-200/80">Generator</p>
              <h2 className="mt-3 text-3xl font-semibold tracking-tight text-white">Turn an idea into a video brief.</h2>
              <p className="mt-3 text-sm leading-6 text-slate-300">
                Fill in the basics, then copy a clean prompt for your free AI video workflow.
              </p>

              <div className="mt-6 space-y-5">
                <div>
                  <FieldLabel>Idea</FieldLabel>
                  <textarea
                    value={form.idea}
                    onChange={(event) => handleChange("idea", event.target.value)}
                    rows={5}
                    className="mt-2 w-full rounded-2xl border border-white/10 bg-slate-950/65 px-4 py-3 text-sm leading-6 text-white outline-none transition placeholder:text-slate-500 focus:border-cyan-300/50"
                    placeholder="Describe the video you want to make..."
                  />
                </div>

                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <FieldLabel>Style</FieldLabel>
                    <select
                      value={form.style}
                      onChange={(event) => handleChange("style", event.target.value)}
                      className="mt-2 w-full rounded-2xl border border-white/10 bg-slate-950/65 px-4 py-3 text-sm text-white outline-none transition focus:border-cyan-300/50"
                    >
                      {styleOptions.map((option) => (
                        <option key={option} value={option} className="bg-slate-950">
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <FieldLabel>Length</FieldLabel>
                    <select
                      value={form.length}
                      onChange={(event) => handleChange("length", event.target.value)}
                      className="mt-2 w-full rounded-2xl border border-white/10 bg-slate-950/65 px-4 py-3 text-sm text-white outline-none transition focus:border-cyan-300/50"
                    >
                      {lengthOptions.map((option) => (
                        <option key={option} value={option} className="bg-slate-950">
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <FieldLabel>Aspect ratio</FieldLabel>
                    <select
                      value={form.ratio}
                      onChange={(event) => handleChange("ratio", event.target.value)}
                      className="mt-2 w-full rounded-2xl border border-white/10 bg-slate-950/65 px-4 py-3 text-sm text-white outline-none transition focus:border-cyan-300/50"
                    >
                      {ratioOptions.map((option) => (
                        <option key={option} value={option} className="bg-slate-950">
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <FieldLabel>Audience</FieldLabel>
                    <select
                      value={form.audience}
                      onChange={(event) => handleChange("audience", event.target.value)}
                      className="mt-2 w-full rounded-2xl border border-white/10 bg-slate-950/65 px-4 py-3 text-sm text-white outline-none transition focus:border-cyan-300/50"
                    >
                      {audienceOptions.map((option) => (
                        <option key={option} value={option} className="bg-slate-950">
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <FieldLabel>Tone</FieldLabel>
                  <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4">
                    {toneOptions.map((option) => {
                      const active = form.tone === option;

                      return (
                        <button
                          key={option}
                          type="button"
                          onClick={() => handleChange("tone", option)}
                          className={`rounded-2xl border px-3 py-3 text-sm font-medium transition ${
                            active
                              ? "border-cyan-300/50 bg-cyan-300/15 text-white"
                              : "border-white/10 bg-slate-950/55 text-slate-300 hover:border-white/20 hover:text-white"
                          }`}
                        >
                          {option}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="flex flex-wrap gap-3 pt-2">
                  <button
                    type="button"
                    onClick={handleGenerate}
                    className="inline-flex items-center justify-center rounded-full bg-white px-5 py-3 text-sm font-semibold text-slate-950 transition hover:bg-cyan-100"
                  >
                    Generate brief
                  </button>
                  <button
                    type="button"
                    onClick={handleCopy}
                    className="inline-flex items-center justify-center rounded-full border border-white/15 bg-white/5 px-5 py-3 text-sm font-semibold text-white transition hover:border-cyan-300/40 hover:bg-white/10"
                  >
                    {copied ? "Copied prompt" : "Copy prompt"}
                  </button>
                </div>
              </div>
            </motion.div>

            <AnimatePresence mode="wait">
              <motion.div
                key={result.prompt}
                className="rounded-[1.75rem] border border-white/10 bg-[linear-gradient(180deg,_rgba(10,16,30,0.9),_rgba(6,10,18,0.96))] p-6 backdrop-blur"
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.55 }}
              >
                <p className="text-xs uppercase tracking-[0.26em] text-cyan-200/80">Preview</p>
                <h3 className="mt-3 text-2xl font-semibold tracking-tight text-white">Your generated video brief</h3>
                <div className="mt-6 space-y-5">
                  <div className="rounded-[1.4rem] border border-white/10 bg-white/5 p-4">
                    <p className="text-xs uppercase tracking-[0.22em] text-slate-400">Prompt</p>
                    <p className="mt-3 text-sm leading-7 text-slate-200">{result.prompt}</p>
                  </div>

                  <div className="grid gap-4 lg:grid-cols-2">
                    <div className="rounded-[1.4rem] border border-white/10 bg-white/5 p-4">
                      <p className="text-xs uppercase tracking-[0.22em] text-slate-400">Scene beats</p>
                      <div className="mt-3 space-y-3">
                        {result.beats.map((beat, index) => (
                          <div key={beat} className="flex gap-3 text-sm leading-6 text-slate-300">
                            <span className="mt-1 inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-cyan-300/15 text-xs font-semibold text-cyan-200">
                              {index + 1}
                            </span>
                            <span>{beat}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="rounded-[1.4rem] border border-white/10 bg-white/5 p-4">
                      <p className="text-xs uppercase tracking-[0.22em] text-slate-400">Export note</p>
                      <p className="mt-3 text-sm leading-7 text-slate-300">{result.exportNote}</p>
                    </div>
                  </div>

                  <div className="rounded-[1.4rem] border border-white/10 bg-white/5 p-4">
                    <p className="text-xs uppercase tracking-[0.22em] text-slate-400">Suggested tool flow</p>
                    <div className="mt-4 space-y-4">
                      {result.toolPath.map((step, index) => (
                        <div key={step.name} className="flex gap-4">
                          <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-white/10 bg-slate-950/80 text-xs font-semibold text-white">
                            {index + 1}
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-white">{step.name}</p>
                            <p className="text-sm leading-6 text-slate-300">{step.detail}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </section>

        <section id="tools" className="border-t border-white/10 bg-[#07101d] px-6 py-16 lg:px-8">
          <div className="mx-auto max-w-7xl">
            <div className="max-w-2xl">
              <p className="text-xs uppercase tracking-[0.26em] text-cyan-200/80">Free tool stack</p>
              <h2 className="mt-3 text-3xl font-semibold tracking-tight text-white">A simple stack for free AI video creation.</h2>
              <p className="mt-3 text-sm leading-6 text-slate-300">
                Tool availability changes often, so treat these as a starting point and check the latest free plans.
              </p>
            </div>

            <div className="mt-10 divide-y divide-white/10 border-y border-white/10">
              {toolRows.map((row) => (
                <div key={row.phase} className="grid gap-3 px-0 py-6 md:grid-cols-[180px_1fr_1fr] md:gap-6">
                  <p className="text-lg font-semibold text-white">{row.phase}</p>
                  <p className="text-sm leading-6 text-slate-300">{row.description}</p>
                  <p className="text-sm leading-6 text-slate-400">Examples to check: {row.examples}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <footer className="bg-[#050816] px-6 py-8 text-sm text-slate-400 lg:px-8">
          <div className="mx-auto flex max-w-7xl flex-col gap-2 border-t border-white/10 pt-8 sm:flex-row sm:items-center sm:justify-between">
            <p>Open Video</p>
            <p>Free AI video workflow for creators, founders, and teams.</p>
          </div>
        </footer>
      </main>
    </div>
  );
}
